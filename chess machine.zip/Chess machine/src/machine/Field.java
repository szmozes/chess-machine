package machine;

import java.awt.Graphics;

public class Field {

	Table table;
	int column;
	int row;
	Piece piece;
	boolean steppable;
	
	public Field(Table table, int row, int column) {
		this.table = table;
		this.row = row;
		this.column = column;
		steppable = false;
	}
	
	public void setPiece(Piece piece) {
		this.piece = piece;
		if(piece != null) {
			piece.field = this;
		}
	}
	
	public void paint(Graphics g, int size) {
		
		// paint the piece
		if(piece != null) {
			piece.paint(g, size);
		}
		
		// and the little sign of opportunity
		if(steppable) {
			g.setColor(new java.awt.Color(160, 160, 160));
			g.drawOval(column*size + size/4, row*size + size/4, size/2, size/2);
		}
	}
}
