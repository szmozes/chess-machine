package machine;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class TablePanel extends JPanel{
	
	Table table;
	int size;	// length of a field in pixels

	public TablePanel() {
		size = 50;	// initial value of 'size'
		setPreferredSize(new Dimension(8*size, 8*size));
		table = new Table(8, 8);
		table.standardLineUp();
	}
	
	public void paint(Graphics g) {
		super.paint(g);
		
		// calculate the current size
		int maxX, maxY; // size of the table in pixels (initial value: maxX='size'*8)
		maxX = this.getWidth();
		maxY = this.getHeight();
		if (maxX>maxY) size = maxY/table.height;
		else size = maxX/table.width;
		
		// background
		for(int i = 0; i < table.height; i++) {
			for(int j = 0; j < table.width; j++) {
				if((i+j)%2 == 0) {
//					g.setColor(new java.awt.Color(255, 255, 127));
					g.setColor(new java.awt.Color(235, 235, 127));
				}
				else {
//					g.setColor(new java.awt.Color(127,  63,  0));
					g.setColor(new java.awt.Color(140, 140, 90));
				}
				g.fillRect(j*size, i*size, size, size);
//				g.fillRect(j*size, i*size, (j+1)*size, (i+1)*size);
			}
		}
		g.setColor(java.awt.Color.BLACK);
		g.drawRect(0, 0, size*table.width-1, size*table.height-1);
		
		// fields
		for(int i = 0; i < table.height; i++) {
			for(int j = 0; j < table.width; j++) {
				table.fields[i][j].paint(g, size);
			}
		}
		
	}
	
	public void addMyMouseListener(Game game) {
		TablePanel p = this;
		p.addMouseListener(new MouseAdapter() {
			
			Piece grabbed;
			
		    @Override 
		    public void mousePressed(MouseEvent e) {
		    	if(e.getButton() == MouseEvent.BUTTON1) {
		    		int column = e.getX()/size;
		    		int row = e.getY()/size;
		    		Field chosenField = p.table.fields[row][column];
		    		if(grabbed == null) {
		    			// grab the piece on the chosen field, and determine the opportunities
			    		grabbed = chosenField.piece;
			    		if(grabbed != null) {
			    			if(grabbed.color == game.whoTurns) {
					    		grabbed.grabbed = true;
					    		p.table.setOpportunities(grabbed);
			    			}
			    			else {
			    				grabbed = null;
			    			}
			    		} 
		    		} 
			    	// if the user wants to make a valid move
		    		else if(chosenField.steppable == true) {
		    			game.userMove(grabbed, row, column);
		    			// go back to choosing state
		    			table.setChoosingState(grabbed);
	    				grabbed = null;
	    			}
		    		// if the user wants to make an invalid move
		    		else if(chosenField.steppable == false) {
		    			// we go back to choosing state
	    				p.table.setChoosingState(grabbed);
	    				grabbed = null;
	    			}
		    	}
		    	p.repaint();
		    }
		});
	}
	
	public static void main(String[] args) {
		
		TablePanel p = new TablePanel();
		Game game = new Game(p.table);
		game.startGameAgainstMachine();
		p.addMyMouseListener(game);
		
		JFrame f = new JFrame();
		f.setContentPane(p);
		f.pack();
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true);
	}
}
