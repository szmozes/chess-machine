package machine;

import java.util.ArrayList;

public class Game {

	Color whoTurns;
	Table table;
	Color machine;
	
	
	public Game(Table t) {
		table = t;
		whoTurns = Color.WHITE;
		machine = null;
	}
	
	public void startGameAgainstMachine() {
		machine = Color.BLACK;
	}
	
	public void makeMove(int depth) {
		int[] bestCoords = new int[4];
		attempt(depth, bestCoords);
		move(table.fields[bestCoords[0]][bestCoords[1]].piece, bestCoords[2], bestCoords[3]);
	}
	
	// this function sets the best move's coordinates
	// the first two is the starting position,
	// the second two is the landing position
	// and returns the best move's state's value
	// note for the usage: it will try to move the turning player's pieces,
	// so we will have to provide the 
	public double attempt(int depth, int[] bestCoords) {
		
		if(depth == 0) {
			return table.state();
		}
		
		else {
			
			// we initialize the best with a safe value
			double best = 0;
			switch(whoTurns) {
			case WHITE: best = -50; break;
			case BLACK: best = 50; break;
			}
			
			// to find the best possible move, we have to search the whole table
			for(int i = 0; i < table.height; i++) {
				for(int j = 0; j < table.width; j++) {
					
					// we found a movable piece, so we will try all its opportunities
					if(table.getPieceColor(i, j) == whoTurns) {
						Piece analyzedPiece = table.fields[i][j].piece;
						ArrayList<int[]> opps = analyzedPiece.opportunities();
						
						// go through all of its opportunities
						for(int[] opp : opps) {
							
							// save the data for the restoration
							int startingRow = analyzedPiece.field.row;
							int startingColumn = analyzedPiece.field.column;
							Piece knocked = table.fields[opp[0]][opp[1]].piece;

							// make a move, and then guess, how good the move was
							move(analyzedPiece, opp[0], opp[1]);
							int[] willBeThrown = new int[4];
							double howGood = attempt(depth-1, willBeThrown);
							
							// make changes back
							table.placePiece(knocked, opp[0], opp[1]);
							table.placePiece(analyzedPiece, startingRow, startingColumn);
							switch(whoTurns) {
							case WHITE: whoTurns = Color.BLACK; break;
							case BLACK: whoTurns = Color.WHITE; break;
							}

							// we found a better move
							if((whoTurns == Color.WHITE && howGood > best) || (whoTurns == Color.BLACK && howGood < best)) {

								best = howGood;
								bestCoords[0] = startingRow;
								bestCoords[1] = startingColumn;
								bestCoords[2] = opp[0];
								bestCoords[3] = opp[1];
							}
						}
					}
				}
			}
			return best;
		}
	}

	// this function is the same as the attempt(), but it also writes its actions
	public double attemptForTest(int depth, int[] bestCoords) {
		
		for(int d = depth; d < 2; d++) {	
			System.out.print("\t");
		}
		System.out.println("attemptForTest called, " + whoTurns + " turns, depth: " + depth);
		
		if(depth == 0) {
			double ret = table.state();

			for(int d = depth; d < 2; d++) {	
				System.out.print("\t");
			}
			System.out.println("depth reached 0, it will return with " + ret + ", " + whoTurns + " will turn");
			
			return ret;
		}
		
		else {
			
			// we initialize the best with a safe value
			double best = 0;
			switch(whoTurns) {
			case WHITE: best = -50; break;
			case BLACK: best = 50; break;
			}
			
			// to find the best possible move, we have to search the whole table
			for(int i = 0; i < table.height; i++) {
				for(int j = 0; j < table.width; j++) {
					
					// we found a movable piece, so we will try all its opportunities
					if(table.getPieceColor(i, j) == whoTurns) {
						Piece analyzedPiece = table.fields[i][j].piece;
						ArrayList<int[]> opps = analyzedPiece.opportunities();
						
						// go through all of its opportunities
						for(int[] opp : opps) {
							
							// save the data for the restoration
							int startingRow = analyzedPiece.field.row;
							int startingColumn = analyzedPiece.field.column;
							Piece knocked = table.fields[opp[0]][opp[1]].piece;

							for(int d = depth; d < 2; d++) {	
								System.out.print("\t");
							}
							System.out.println("we will make a move from " + startingRow + " " + startingColumn + " to " + opp[0] + " " + opp[1]);
							
							// make a move, and then guess, how good the move was
							move(analyzedPiece, opp[0], opp[1]);

							for(int d = depth; d < 2; d++) {	
								System.out.print("\t");
							}
							System.out.println("we will guess how good it was");

							int[] willBeThrown = new int[4];
							double howGood = attemptForTest(depth-1, willBeThrown);
							
							// make things back
							table.placePiece(knocked, opp[0], opp[1]);
							table.placePiece(analyzedPiece, startingRow, startingColumn);
							switch(whoTurns) {
							case WHITE: whoTurns = Color.BLACK; break;
							case BLACK: whoTurns = Color.WHITE; break;
							}

							for(int d = depth; d < 2; d++) {	
								System.out.print("\t");
							}
							System.out.println("move from " + startingRow + " " + startingColumn + " to " + opp[0] + " " + opp[1] + " was " + howGood + " good");
	
							// we found a better move
							if((whoTurns == Color.WHITE && howGood > best) || (whoTurns == Color.BLACK && howGood < best)) {

								for(int d = depth; d < 2; d++) {	
									System.out.print("\t");
								}
								System.out.print("found a new best move, it is " + howGood + " good");
								
								best = howGood;
								bestCoords[0] = startingRow;
								bestCoords[1] = startingColumn;
								bestCoords[2] = opp[0];
								bestCoords[3] = opp[1];
								System.out.println(", params: " + bestCoords[0] + " " + bestCoords[1] + " " + bestCoords[2] + " " + bestCoords[3]);
							}
							
						}
					}
				}
			}
			return best;
		}
	}

	
	public void move(Piece piece, int row, int column) {
		
		// we execute the move, 
		table.placePiece(null, piece.field.row, piece.field.column);
		table.placePiece(piece, row, column);
		
		// and set who turns
		switch(whoTurns) {
		case WHITE: whoTurns = Color.BLACK; break;
		case BLACK: whoTurns = Color.WHITE; break;
		}
	}
	
	public void userMove(Piece piece, int row, int column) {

		// we execute the move, 
		table.placePiece(null, piece.field.row, piece.field.column);
		table.placePiece(piece, row, column);

		// and set who turns
		switch(whoTurns) {
		case WHITE: whoTurns = Color.BLACK; break;
		case BLACK: whoTurns = Color.WHITE; break;
		}

		if(whoTurns == machine) {
			makeMove(4);
		}
	}
	
}
