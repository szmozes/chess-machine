package machine;

public class Game {

	Color who_sTurn;
	Table table;
	
	public Game(Table t) {
		table = t;
		who_sTurn = Color.WHITE;
	}
	
	public void startGame() {
		
	}
	

	// this function is far from complete
	public double attempt(int depth) {
		if(depth == 0) {
			return table.state();
		}
		else {
			return 0;
		}
	}
	
	public void move(Piece piece, int row, int column) {
		// we execute the move, 
		table.placePiece(null, piece.field.row, piece.field.column);
		table.placePiece(piece, row, column);
		// and go back to choosing state
		table.setChoosingState(piece);
		
		switch(who_sTurn) {
		case WHITE: who_sTurn = Color.BLACK; break;
		case BLACK: who_sTurn = Color.WHITE; break;
		}
	}
}
