package machine;

public enum Color {
	BLACK,
	WHITE
}
