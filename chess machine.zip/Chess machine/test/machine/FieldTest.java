package machine;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;


public class FieldTest {
	
	Field field;

	@Before
	public void setUp() {
		field = new Field(null, 3, 3);
	}
	
	@Test
	public void testSetPieceGetPiece() {
		Table table = new Table(8, 8);
		Piece piece = new Piece(null, Color.WHITE);
		field.setPiece(piece);
		Assert.assertNotNull(field.getPiece());
	}

}
