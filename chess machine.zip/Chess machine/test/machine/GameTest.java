package machine;

import org.junit.Before;
import org.junit.Test;

public class GameTest {
	
	Table table;
	Game game;
	
	/*
	 A - Ally
	 E - Enemy
	 O - Test
	 
	   ___________________
	   |\|0|1|2|3|4|5|6|7|
	   |0|_|_|_|Q|_|_|_|_|
	   |1|_|_|_|_|_|_|_|_|
	   |2|_|_|_|_|_|_|R|_|
	   |3|_|_|_|_|_|_|_|_|
	   |4|_|_|_|_|B|_|_|_|
	   |5|_|_|_|_|_|_|_|_|
	   |6|_|_|_|_|_|_|_|_|
	   |7|_|_|_|_|_|_|_|_|
	   
	 */
	
	@Before
	public void setUp() {
		table = new Table(8, 8);
		game = new Game(table);
	}
	
	@Test
	public void attemptTest() {
		table.placePiece(new Bishop(null, Color.WHITE), 4, 4);
		table.placePiece(new Queen(null, Color.BLACK), 0, 3);
		table.placePiece(new Rook(null, Color.BLACK), 2, 6);
		table.write();
		int[] bestMove = new int[4];
		double state = game.attempt(1, bestMove);
		System.out.println(state + " " + bestMove[0] + " " + bestMove[1] + " " + bestMove[2] + " " + bestMove[3]);
	}
}
